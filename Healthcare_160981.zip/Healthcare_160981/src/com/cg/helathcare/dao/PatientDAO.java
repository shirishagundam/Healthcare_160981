package com.cg.helathcare.dao;

import java.util.List;

import com.cg.healthcare.model.Patient;
import com.cg.helathcare.exceptions.HealthCareException;

public interface PatientDAO {

	int fixAppointment(Patient patient) throws HealthCareException;
	public String getDoctorName(String problemName) throws HealthCareException;
	public int SearchPatient(int  id)throws HealthCareException;
	List<Patient> searchId(int id) throws HealthCareException;

}
